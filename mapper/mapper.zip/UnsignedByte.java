public class UnsignedByte {
  public static int toInt(byte b) {
	return (int)b & 0xFF;
  }
}
